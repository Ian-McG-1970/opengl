#ifndef GAME
#define GAME

#include <windows.h>

#define STRICT
#define WIN32_LEAN_AND_MEAN

#define MAP_VER 250
#define MAP_HOR 350
#define SCALE 1
#define	FramesSecond 50
#define	MillisecondsFrame 1000/FramesSecond

#define iso_top 100l
#define iso_left 150l

struct xy
{
	int x;
	int y;
};

struct xyz
{
	int x;
	int y;
	int z;
};

struct obj
{
	xyz centre;
	xyz min;
	xyz max;
	xy overlap_x;
	xy overlap_y;
	xy overlap_h;
	int shape;
	xy pos;
	bool behind;
};

const xyz shape_dimension[]={{4,4,4},{8,8,8},{4,4,8},{8,4,4},{4,8,4},{8,4,8},{4,8,8},{8,2,8},{2,8,8}
};
const xy shape_offset[]={    {8,8},  {16,16},{12,8}, {10,12},{10,12},{14,12},{14,12}, {13,10},{13,10}
};
const xy shape_size[]={      {16,16},{32,32},{24,16},{20,24},{20,24},{28,24},{28,24}, {26,20},{26,20}
};
const BYTE shape_colour[][3]={ {1,2,3},{5,3,1},{4,1,2},{2,3,4},{3,5,1},{1,3,5},{5,4,2},{4,3,2},{2,5,3},
};

const unsigned long Colour[]={
	(0*65536)+(0*256)+0, 
	(63*65536)+(63*256)+63, 
	(191*65536)+(0*256)+0, 
	(0*65536)+(191*256)+0, 
	(0*65536)+(0*256)+191,
	(255*65536)+(255*256)+255,
	(191*65536)+(191*256)+191,
	(127*65536)+(127*256)+127,
	(63*65536)+(63*256)+63,
	(255*65536)+(0*256)+0,
	(191*65536)+(0*256)+0,
	(127*65536)+(0*256)+0,
	(63*65536)+(9*256)+0,
	(0*65536)+(255*256)+0,
	(0*65536)+(191*256)+0,
	(0*65536)+(127*256)+0,
	(0*65536)+(63*256)+0,};

class Game
{
public:
	const void Setup();
	const void Update();

private:
	long screen[MAP_VER][MAP_HOR];
	char string[256];
	int objects;
	int drawn;
	obj object[256];
	int object_pos[256];

	const xyz XYZ(const int, const int, const int);
	const void SortObjectList(const int);
const bool IsBehind2(const xy &, const xy &);
const bool IsBehind(const obj &, const obj &);

const xy XY(const int, const int);
const void Plot(const xy, const BYTE);
const void clearScreen();
const xy IsometricPoint(const xyz &);
const void AddObject(const int);
const bool Movement(const xyz &, const int);
const bool Collision(const obj &, const obj &);
const void Draw2D(const int, const BYTE);
const void DrawFast(const obj &);
const bool Overlap(const obj &, const obj &);

};

#endif
