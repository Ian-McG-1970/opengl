#ifndef CWINDOW
#define CWINDOW

#include <windows.h>

struct SParameters
{
	bool fullscreen;
	short width;
	short height;
	char *pMenu;
	char *pTitle;
};

class CWindow
{
public:
	const HRESULT Setup(const SParameters &, const HINSTANCE);
	const bool CheckMessage();
	const HWND GetHandle();
private:
	HWND hWnd;
	LRESULT MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
};

#endif
