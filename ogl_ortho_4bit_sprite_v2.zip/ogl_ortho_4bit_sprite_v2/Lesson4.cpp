/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing The Base Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include <windows.h>
#include <stdio.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

#define HOR 640 //1024
#define VER 480 //768
#define BPP 32

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool active=true;		// Window Active Flag Set To TRUE By Default
bool fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

WORD HPos=20, VPos=20;

//FILE *file;
//char string[256];

typedef struct
{
	int Number;
	unsigned char* Bitmap;
	int Size;
	int VerSize;
	int HorSize;
	GLubyte* Texture;
	unsigned long Alpha; // does the texture have alpha or not? is the format rgb / glubyte[3] or rgba / glubyte[4]?
} Sprite;

Sprite Sprites[255];

unsigned long long testvar=0x0ffffffffffffffff;

//const void debugstring() { file=fopen("log.txt","a"); fprintf(file,string); fclose(file); }

// const unsigned char Colour[4][4]; [4] colours * [4] rgba

const void SwitchVsync(const bool sync)
{
	BOOL (APIENTRY *wglSwapIntervalEXT)(int);
	wglSwapIntervalEXT=( BOOL (APIENTRY*)(int) )wglGetProcAddress("wglSwapIntervalEXT");
//	if (sync==true)
//	{
//		wglSwapIntervalEXT(1);
//	}
//	else
//	{
//		wglSwapIntervalEXT(0);
//	}
	wglSwapIntervalEXT(sync);
}

const void SetColour (const unsigned long colour, unsigned char* out)
{
	out[0]=(colour >>16) &255;
	out[1]=(colour >>8) &255;
	out[2]=colour &255;
	out[3]=255;
}

const void ColourToTexture(const unsigned char in, const unsigned long colour1, const unsigned long colour2, const unsigned long colour3, unsigned char* out)
{
	switch (in)
	{
		case 0:
		{
			out[0]=out[1]=out[2]=out[3]=0;
			break;
		}
		case 1:
		{
			SetColour(colour1, out);
			break;
		}
		case 2:
		{
			SetColour(colour2, out);
			break;
		}
		case 3:
		{
			SetColour(colour3, out);
			break;
		}
	}
}

const void CharToBytes(GLubyte char_in, GLubyte* byte_out)
{
	for (int i=0, shift=6; i!=4; ++i, shift-=2)
	{
		byte_out[i]=( (char_in >>shift) & 0x03);
	}	
}

const void ByteToTexture(const GLubyte *in, const unsigned long colour1, const unsigned long colour2, const unsigned long colour3, GLubyte *out)
{
	for (int i=0, o=0; i!=4; ++i, o+=4)
	{
		ColourToTexture(in[i], colour1, colour2, colour3, &out[o]);
	}	
}

const void CreateTextureFromBitmap(const unsigned char *bitmap_in, const int ver_size, const int hor_size, const unsigned long colour1, const unsigned long colour2, const unsigned long colour3, const bool alpha_included, GLubyte* texture_out)
{
	GLubyte conversion[4];
	const int hor_colours_within_char=hor_size/4;

	for (int i=0, o=0, v=0; v!=ver_size; ++v)
	{
		for (int h=0; h!=hor_colours_within_char; ++h, ++i, o+=16)
		{
			CharToBytes(bitmap_in[i], &conversion[0]);
			ByteToTexture(&conversion[0], colour1, colour2, colour3, &texture_out[o]);
		}
	}
}

const unsigned char bitmap0[]={
0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x1,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0xF5,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x2,	0xAD,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0xA9,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x1B,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x1B,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x1E,	0x0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x1E,	0xC0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x17,	0x80,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x7,	0x80,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0xA,	0xC0,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x2A,	0x50,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0xAD,	0x50,	0x0,	0x0,	0x0,	0x0,	0x0,
0xA,	0xBD,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,
0xB,	0x5,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x15,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x55,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,
0x1,	0x55,	0x50,	0x0,	0x0,	0x0,	0x0,	0x0,
0x1,	0x55,	0x40,	0x0,	0x0,	0x0,	0x0,	0x0,
0x5,	0x51,	0x40,	0x0,	0x0,	0x0,	0x0,	0x0,
0x5,	0x51,	0x50,	0x0,	0x0,	0x0,	0x0,	0x0,
0x1,	0x50,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,
0x1,	0x54,	0x54,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x54,	0x15,	0x0,	0x0,	0x0,	0x0,	0x0,
0x0,	0x15,	0x5,	0x40,	0x0,	0x0,	0x0,	0x0,
0x0,	0x5,	0x1,	0x40,	0x0,	0x0,	0x0,	0x0,
0x0,	0x5,	0x5,	0x40,	0x0,	0x0,	0x0,	0x0,
0x0,	0x55,	0x15,	0x0,	0x0,	0x0,	0x0,	0x0,
};

const unsigned char bitmap1[]={
0x55,	0x55,	0x55,	0x40,
0x55,	0x55,	0x55,	0x60,
0x5A,	0xAA,	0xA9,	0x6C,
0x5B,	0xFF,	0xFD,	0x6C,
0x5B,	0x0,	0x1,	0x6C,
0x5B,	0x0,	0x1,	0x6C,
0x5B,	0x0,	0x1,	0x6C,
0x5B,	0x0,	0x1,	0x6C,
0x5B,	0x0,	0x1,	0x6C,
0x5B,	0x0,	0x1,	0x6C,
0x55,	0x55,	0x55,	0x6C,
0x55,	0x55,	0x55,	0x6C,
0x55,	0x55,	0x55,	0x6C,
0x2A,	0xAA,	0xAA,	0xAC,
0xF,	0xFF,	0xFF,	0xFC,
0x0,	0x0,	0x0,	0x0,
};

const unsigned char bitmap2[]={
0x0,	0x0,	0x0,	0x1,	0x40,	0x0,	0x0,	0x0,
0x0,	0x0,	0x0,	0x16,	0xD4,	0x0,	0x0,	0x0,
0x0,	0x0,	0x1,	0x7B,	0xB9,	0x40,	0x0,	0x0,
0x0,	0x0,	0x16,	0xEE,	0xEE,	0xD4,	0x0,	0x0,
0x0,	0x1,	0x7B,	0xBB,	0xBB,	0xB9,	0x40,	0x0,
0x0,	0x16,	0xEE,	0xEE,	0xEE,	0xEE,	0xD4,	0x0,
0x1,	0x7B,	0xBB,	0xBB,	0xBB,	0xBB,	0xB9,	0x40,
0x16,	0xEE,	0xEE,	0xEE,	0xEE,	0xEE,	0xEE,	0xD4,
0x7B,	0xBB,	0xBB,	0xBB,	0xBB,	0xBB,	0xBB,	0xB9,
0x56,	0xEE,	0xEE,	0xEE,	0xEE,	0xEE,	0xEE,	0xD5,
0x69,	0x7B,	0xBB,	0xBB,	0xBB,	0xBB,	0xB9,	0x7D,
0x6A,	0x96,	0xEE,	0xEE,	0xEE,	0xEE,	0xD7,	0xFD,
0x6A,	0xA9,	0x7B,	0xBB,	0xBB,	0xB9,	0x7F,	0xFD,
0x6A,	0xAA,	0x96,	0xEE,	0xEE,	0xD7,	0xFF,	0xFD,
0x6A,	0xAA,	0xA9,	0x7B,	0xB9,	0x7F,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0x96,	0xD7,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xA9,	0x7F,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x6A,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xFD,
0x16,	0xAA,	0xAA,	0xAA,	0xFF,	0xFF,	0xFF,	0xD4,
0x1,	0x6A,	0xAA,	0xAA,	0xFF,	0xFF,	0xFD,	0x40,
0x0,	0x16,	0xAA,	0xAA,	0xFF,	0xFF,	0xD4,	0x0,
0x0,	0x1,	0x6A,	0xAA,	0xFF,	0xFD,	0x40,	0x0,
0x0,	0x0,	0x16,	0xAA,	0xFF,	0xD4,	0x0,	0x0,
0x0,	0x0,	0x1,	0x6A,	0xFD,	0x40,	0x0,	0x0,
0x0,	0x0,	0x0,	0x16,	0xD4,	0x0,	0x0,	0x0,
0x0,	0x0,	0x0,	0x1,	0x40,	0x0,	0x0,	0x0,
};

typedef struct
{
	GLubyte Image[64*64*4];
	int Width;
	int Height;
} Texture;

static Texture TextureList[255];

const void InitTexture(const unsigned char *bitmap_in, const int height, const int width, const unsigned long colour1, const unsigned long colour2, const unsigned long colour3, const bool alpha_included, const int texture_number)
{
	TextureList[texture_number].Width=width;
	TextureList[texture_number].Height=height;
	CreateTextureFromBitmap(bitmap_in, 32, 32, colour1, colour2, colour3, alpha_included, &TextureList[texture_number].Image[0]);// ,  &texture0[0]);
}

const void InitTextures()
{
//	InitTexture(&bitmap0[0], 32, 32, 0x00ff0000, 0x00aa0000, 0x00550000, true, 0);// ,  &texture0[0]);
//	InitTexture(&bitmap0[0], 32, 32, 0x0000ff00, 0x0000aa00, 0x00005500, true, 1);//&texture1[0]);
//	InitTexture(&bitmap0[0], 32, 32, 0x000000ff, 0x000000aa, 0x00000055, true, 2);//&texture2[0]);
	
	InitTexture(&bitmap0[0],32,32, 0x00777777, 0x00888888, 0x00ffff77, true, 0);
	InitTexture(&bitmap0[0],32,32, 0x00333333, 0x00af7f7f, 0x00eeeeee, true, 1);
	InitTexture(&bitmap0[0],32,32, 0x00111111, 0x00af7f7f, 0x00ffff77, true, 2);

	InitTexture(&bitmap1[0],16,16, 0x00ff0000, 0x0000ff00, 0x000000ff, true, 3);
	InitTexture(&bitmap1[0],16,16, 0x00ff00ff, 0x0000ffff, 0x00ffff00, true, 4);
	InitTexture(&bitmap1[0],16,16, 0x00eeeeee, 0x00aaaaaa, 0x00555555, true, 5);

	InitTexture(&bitmap2[0],32,32, 0x00ff0000, 0x0000ff00, 0x000000ff, true, 6);
	InitTexture(&bitmap2[0],32,32, 0x00ff00ff, 0x0000ffff, 0x00ffff00, true, 7);
	InitTexture(&bitmap2[0],32,32, 0x00eeeeee, 0x00aaaaaa, 0x00555555, true, 8);
}

const GLvoid ReSizeGLScene(const GLsizei width, const GLsizei height)		// Resize And Initialize The GL Window
{
	glViewport(0,0,width,height);						// Reset The Current Viewport
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	gluOrtho2D(0,width,height,0);
}

const bool InitGL()										// All Setup For OpenGL Goes Here
{
	glShadeModel(GL_FLAT);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);				// Black Background
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	// Really Nice Perspective Calculations
	glPolygonMode( GL_FRONT_AND_BACK, GL_FILL); // GL_FILL GL_LINE
	return true;										// Initialization Went OK
}

const void DrawBox(const float top, const float bottom, const float left, const float right, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(left, top);
		glVertex2f(right, top);
		glVertex2f(right, bottom);
		glVertex2f(left, bottom);
	glEnd();
}

const void DrawSprite(const float top, const float left, const float height, const float width, GLubyte *image)
{
	const float bottom=top+height;
	const float right=left+width;
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA, GL_UNSIGNED_BYTE, image);
	
	glBegin(GL_QUADS);              // Each set of 4 vertices form a quad
	glTexCoord2f(0,0);
	glVertex2f(left, top);
	
	glTexCoord2f(1,0);
    glVertex2f(right, top);
    
    glTexCoord2f(1,1);
    glVertex2f(right, bottom);
    
    glTexCoord2f(0,1);
    glVertex2f(left, bottom);
   	glEnd();
}

/*
int main ()
{
  int i,n;
  int * p;
  cout << "How many numbers would you like to type? ";
  cin >> i;
  p= new (nothrow) int[i];
  if (p == nullptr)
    cout << "Error: memory could not be allocated";
  else
  {
    for (n=0; n<i; n++)
    {
      cout << "Enter number: ";
      cin >> p[n];
    }
    cout << "You have entered: ";
    for (n=0; n<i; n++)
      cout << p[n] << ", ";
    delete[] p;
  }
  return 0;
}
*/

const void DrawSquare(const float top, const float left, const float size, const float colour)
{
	const float bottom=top+size;
	const float right=left+size;
	
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(left, top);
		glVertex2f(right, top);
		glVertex2f(right, bottom);
		glVertex2f(left, bottom);
	glEnd();
}

const void DrawRectangle(const float p1h, const float p1v, const float p2h, const float p2v, const float p3h, const float p3v, const float p4h, const float p4v, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(p1h, p1v);
		glVertex2f(p2h, p2v);
		glVertex2f(p3h, p3v);
		glVertex2f(p4h, p4v);
	glEnd();
}

const void DrawTriangle(const float p1h, const float p1v, const float p2h, const float p2v, const float p3h, const float p3v, const float colour)
{
	glBegin(GL_TRIANGLES);
		glColor3f(colour, colour, colour);
		glVertex2f(p1h, p1v);
		glVertex2f(p2h, p2v);
		glVertex2f(p3h, p3v);
	glEnd();
}

const void SpriteDraw(const int Texture, const float Hor, const float Ver)
{
    const float width = TextureList[Texture].Width;
    const float height = TextureList[Texture].Height;
	DrawSprite(Ver, Hor, height,width/*height, width*/, &TextureList[Texture].Image[0]);
}

const bool DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	ReSizeGLScene(HOR, VER); // Reset The Current Viewport
		
	SpriteDraw(1, 50, 50);//, renderer);
	SpriteDraw(0, HPos, VPos);// renderer);
	SpriteDraw(2, 100, 100);//, renderer);

	SpriteDraw(3, 150, 150);//, renderer);
	SpriteDraw(4, 200, 200);//, renderer);
	SpriteDraw(5, 250, 250);//, renderer);

	SpriteDraw(6, 300, 300);//, renderer);
	SpriteDraw(7, 350, 350);//, renderer);

	SpriteDraw(8, 400, 400);//, renderer);

//	SpriteDraw(6, 100, 100);//, renderer);
//	SpriteDraw(7, 300, 300);//, renderer);
//	SpriteDraw(8, 300, 100);//, renderer);
	return true;										// Keep Going
}

const GLvoid KillGLWindow()								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			}
			break;
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:
		{
			return 0;
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}
	return DefWindowProc(hWnd,uMsg,wParam,lParam); // Pass All Unhandled Messages To DefWindowProc
}
 
const bool CreateGLWindow(const char* title, const int width, const int height, const unsigned char bpp, const bool fullscreenflag)
{
	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	WNDCLASS wc;
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name
	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bpp;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL) // Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		{
			MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
			return FALSE;
		}
	}
	
	DWORD dwExStyle;
	DWORD dwStyle;

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	RECT WindowRect={0,0,width,height};	// Grabs Rectangle Upper Left / Lower Right Values
	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);		// Adjust Window To True Requested Size

	if (!(hWnd=CreateWindowEx(dwExStyle, "OpenGL", title, dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance, NULL))) // Create The Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd= {sizeof(PIXELFORMATDESCRIPTOR), 1, PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA, bpp, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 00, 0, 0,PFD_MAIN_PLANE, 0,0, 0, 0}; // pfd Tells Windows How We Want Things To Be
	if (!(hDC=GetDC(hWnd)))						// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	GLuint PixelFormat;			// Holds The Results After Searching For A Match
	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}
	
	InitTextures();
	glEnable(GL_TEXTURE_2D);
	
    glEnable( GL_BLEND );
    glDisable( GL_DEPTH_TEST );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    
    SwitchVsync(true);
    
	return true;									// Success
}

const void Input()
{
			if (GetAsyncKeyState(VK_UP) & 0x8001) --VPos;
			if (GetAsyncKeyState(VK_DOWN) & 0x8001) ++VPos;
			if (GetAsyncKeyState(VK_LEFT) & 0x8001) --HPos;
			if (GetAsyncKeyState(VK_RIGHT) & 0x8001) ++HPos;
			if (GetAsyncKeyState(VK_ESCAPE) & 0x8001) PostQuitMessage(0);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	if (!CreateGLWindow("NeHe's First Polygon Tutorial",HOR,VER,BPP,true)) // Create Our OpenGL Window
	{
		return 0;									// Quit If Window Was Not Created
	}

	MSG	msg;									// Windows Message Structure
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			Input();
			DrawGLScene();
			SwapBuffers(hDC);
			glFinish();
		}
	}

/*	while (true)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				break;
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if (active && !DrawGLScene())	// Active?  Was There A Quit Received?
			{
				break;
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
//				glFinish();

			}
		}
	}
*/
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}

/*
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			DrawGLScene();
			SwapBuffers(hDC);
//			engine.Update();
		}
	}
*/

