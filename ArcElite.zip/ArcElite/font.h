void txtOut(float x, float y, char *s, float size );

float _A[] = { 1,1, 1,5, 5,5, 5,1, 5,3, 1,3, -1 };
float _B[] = { 1,1, 1,5, 3,5, 3,3, 1,3, 5,3, 5,1, 1,1, -1 };
float _C[] = { 5,1, 1,1, 1,5, 5,5, -1 };
float _D[] = { 1,1, 1,5, 3,5, 5,3, 5,1, 1,1, -1 };
float _E[] = { 5,1, 1,1, 1,3, 3,3, 1,3, 1,5, 5,5, -1 };
float _F[] = { 1,1, 1,3, 3,3, 1,3, 1,5, 5,5, -1 };
float _G[] = { 5,5, 1,5, 1,1, 5,1, 5,3, 2,3, -1 };
float _H[] = { 1,1, 1,5, 1,3, 5,3, 5,5, 5,1, -1 };
float _I[] = { 2,1, 4,1, 3,1, 3,5, 2,5, 4,5, -1 };
float _J[] = { 2,5, 5,5, 5,1, 1,1, 1,3, -1 };
float _K[] = { 1,1, 1,5, 1,3, 5,5, 1,3, 5,1, -1 };
float _L[] = { 1,5, 1,1, 5,1, -1 };
float _M[] = { 1,1, 1,5, 3,5, 3,3, 3,5, 5,5, 5,1, -1 };
float _N[] = { 1,1, 1,5, 5,1, 5,5, -1 };
float _O[] = { 1,1, 1,5, 5,5, 5,1, 1,1, -1 };
float _P[] = { 1,1, 1,5, 5,5, 5,3, 1,3, -1 };
float _Q[] = { 3,3, 5,1, 1,1, 1,5, 5,5, 5,1, -1 };
float _R[] = { 1,1, 1,5, 5,5, 5,3, 1,3, 5,1, -1 };
float _S[] = { 5,5, 1,5, 1,3, 5,3, 5,1, 1,1, -1 };
float _T[] = { 1,5, 5,5, 3,5, 3,1, -1 };
float _U[] = { 1,5, 1,1, 5,1, 5,5, -1 };
float _V[] = { 1,5, 3,1, 5,5, -1 };
float _W[] = { 1,5, 1,1, 3,1, 3,3, 3,1, 5,1, 5,5, -1 };
float _X[] = { 1,5, 5,1, 3,3, 1,1, 3,3, 5,5, -1 };
float _Y[] = { 1,5, 3,3, 3,1, 3,3, 5,5, -1 };
float _Z[] = { 1,5, 5,5, 1,1, 5,1, -1 };

float _a[] = { 1,3, 4,3, 4,1, 1,1, 1,2, 4,2, -1 };
float _b[] = { 1,5, 1,1, 4,1, 4,3, 1,3, -1 };
float _c[] = { 4,1, 1,1, 1,3, 4,3, -1 };
float _d[] = { 4,5, 4,1, 1,1, 1,3, 4,3, -1 };
float _e[] = { 4,1, 1,1, 1,3, 4,3, 4,2, 1,2, -1 };
float _f[] = { 3,0, 3,3, 2,3, 5,3, 3,3, 3,5, 5,5, -1 };
float _g[] = { 1,0, 4,0, 4,3, 1,3, 1,1, 4,1, -1 };
float _h[] = { 1,1, 1,5, 1,3, 4,3, 4,1, -1 };
float _i[] = { 2,1, 4,1, 3,1, 3,3, 2,3, 4,3, -1 };
float _j[] = { 3,3, 4,3, 4,0, 2,0, -1 };
float _k[] = { 1,1, 1,5, 1,2, 3,3, 1,2, 4,1, -1 };
float _l[] = { 2,5, 2,1, 3,1, -1 };
float _m[] = { 1,1, 1,3, 3,3, 3,1, 3,3, 5,3, 5,1, -1 };
float _n[] = { 1,1, 1,3, 4,3, 4,1, -1 };
float _o[] = { 1,1, 1,3, 4,3, 4,1, 1,1, -1 };
float _p[] = { 1,0, 1,3, 4,3, 4,1, 1,1, -1 };
float _q[] = { 4,0, 4,3, 1,3, 1,1, 4,1, -1 };
float _r[] = { 1,1, 1,3, 1,2, 4,3, -1 };
float _s[] = { 4,3, 1,3, 1,2, 4,2, 4,1, 1,1, -1 };
float _t[] = { 3,1, 3,3, 2,3, 5,3, 3,3, 3,5, -1 };
float _u[] = { 1,3, 1,1, 4,1, 4,3, -1 };
float _v[] = { 1,3, 3,1, 5,3, -1 };
float _w[] = { 1,3, 1,1, 3,1, 3,2, 3,1, 5,1, 5,3, -1 };
float _x[] = { 1,3, 5,1, 3,2, 1,1, 3,2, 5,3, -1 };
float _y[] = { 1,3, 1,1, 4,1, 4,3, 4,0, 1,0, -1 };
float _z[] = { 1,3, 4,3, 1,1, 4,1, -1 };

float _0[] = { 1,1, 1,5, 5,5, 5,1, 1,1, 5,5, -1 };
float _1[] = { 1,1, 5,1, 3,1, 3,5, 1,3, -1 };
float _2[] = { 1,5, 5,5, 5,3, 1,3, 1,1, 5,1, -1 };
float _3[] = { 1,5, 5,5, 5,3, 3,3, 5,3, 5,1, 1,1, -1 };
float _4[] = { 5,2, 1,2, 4,5, 4,1, -1 };
float _5[] = { 5,5, 1,5, 1,3, 5,3, 1,1, -1 };
float _6[] = { 1,5, 1,1, 5,1, 5,3, 1,3, -1 };
float _7[] = { 1,5, 5,5, 1,1, -1 };
float _8[] = { 1,3, 1,1, 5,1, 5,5, 1,5, 1,3, 5,3, -1 };
float _9[] = { 5,1, 5,5, 1,5, 1,3, 5,3, -1 };

float _dot[] = { 2,1, 3,1, -1 };
float _2dot[] = { 1,1, 3,1, 1,3, 1,1, -1 };
float _aposf[] = { 2,5, 3,3, -1 };
float _coma[] = { 2,0, 3,2, -1 };
float _plus[] = { 1,3, 5,3, 3,3, 3,5, 3,1, -1 };
float _minus[] = { 1,3, 4,3, -1 };
float _lbrac[] = { 3,5, 2,3, 3,1, -1 };
float _rbrac[] = { 3,5, 4,3, 3,1, -1 };
float _less[] = { 4,1, 1,3, 4,5, -1 };
float _great[] = { 1,1, 4,3, 1,5, -1 };
float _div[] = { 1,1, 4,5, -1 };
float _and[] = { 4,0, 4,3, 1,3, 1,5, 3,5, 3,3, 1,3, 1,1, 6,1, -1 };
float _equal[] = { 1,1, 1,5, 5,3, 1,1,  -1 };


void drawLetter(float l[])
{
	
	int i=0;

	glBegin(GL_LINE_STRIP);

		while(l[i]!= -1)
		{

			glVertex2f(l[i], l[i+1]);

			i+= 2;
		}
	glEnd();
	
	glTranslatef(6.0, 0.0, 0.0);	   

}

/*  Create a display list for each of 6 characters	*/
void initFONT(void)
{
   GLuint base;

   base = glGenLists (128);
   glListBase(base);
   glNewList(base+'A', GL_COMPILE); drawLetter(_A); glEndList();
   glNewList(base+'B', GL_COMPILE); drawLetter(_B); glEndList();
   glNewList(base+'C', GL_COMPILE); drawLetter(_C); glEndList();
   glNewList(base+'D', GL_COMPILE); drawLetter(_D); glEndList();
   glNewList(base+'E', GL_COMPILE); drawLetter(_E); glEndList();
   glNewList(base+'F', GL_COMPILE); drawLetter(_F); glEndList();
   glNewList(base+'G', GL_COMPILE); drawLetter(_G); glEndList();
   glNewList(base+'H', GL_COMPILE); drawLetter(_H); glEndList();
   glNewList(base+'I', GL_COMPILE); drawLetter(_I); glEndList();
   glNewList(base+'J', GL_COMPILE); drawLetter(_J); glEndList();
   glNewList(base+'K', GL_COMPILE); drawLetter(_K); glEndList();
   glNewList(base+'L', GL_COMPILE); drawLetter(_L); glEndList();
   glNewList(base+'M', GL_COMPILE); drawLetter(_M); glEndList();
   glNewList(base+'N', GL_COMPILE); drawLetter(_N); glEndList();
   glNewList(base+'O', GL_COMPILE); drawLetter(_O); glEndList();
   glNewList(base+'P', GL_COMPILE); drawLetter(_P); glEndList();
   glNewList(base+'Q', GL_COMPILE); drawLetter(_Q); glEndList();
   glNewList(base+'R', GL_COMPILE); drawLetter(_R); glEndList();
   glNewList(base+'S', GL_COMPILE); drawLetter(_S); glEndList();
   glNewList(base+'T', GL_COMPILE); drawLetter(_T); glEndList();
   glNewList(base+'U', GL_COMPILE); drawLetter(_U); glEndList();
   glNewList(base+'V', GL_COMPILE); drawLetter(_V); glEndList();
   glNewList(base+'W', GL_COMPILE); drawLetter(_W); glEndList();
   glNewList(base+'X', GL_COMPILE); drawLetter(_X); glEndList();
   glNewList(base+'Y', GL_COMPILE); drawLetter(_Y); glEndList();
   glNewList(base+'Z', GL_COMPILE); drawLetter(_Z); glEndList();

   glNewList(base+'a', GL_COMPILE); drawLetter(_a); glEndList();
   glNewList(base+'b', GL_COMPILE); drawLetter(_b); glEndList();
   glNewList(base+'c', GL_COMPILE); drawLetter(_c); glEndList();
   glNewList(base+'d', GL_COMPILE); drawLetter(_d); glEndList();
   glNewList(base+'e', GL_COMPILE); drawLetter(_e); glEndList();
   glNewList(base+'f', GL_COMPILE); drawLetter(_f); glEndList();
   glNewList(base+'g', GL_COMPILE); drawLetter(_g); glEndList();
   glNewList(base+'h', GL_COMPILE); drawLetter(_h); glEndList();
   glNewList(base+'i', GL_COMPILE); drawLetter(_i); glEndList();
   glNewList(base+'j', GL_COMPILE); drawLetter(_j); glEndList();
   glNewList(base+'k', GL_COMPILE); drawLetter(_k); glEndList();
   glNewList(base+'l', GL_COMPILE); drawLetter(_l); glEndList();
   glNewList(base+'m', GL_COMPILE); drawLetter(_m); glEndList();
   glNewList(base+'n', GL_COMPILE); drawLetter(_n); glEndList();
   glNewList(base+'o', GL_COMPILE); drawLetter(_o); glEndList();
   glNewList(base+'p', GL_COMPILE); drawLetter(_p); glEndList();
   glNewList(base+'q', GL_COMPILE); drawLetter(_q); glEndList();
   glNewList(base+'r', GL_COMPILE); drawLetter(_r); glEndList();
   glNewList(base+'s', GL_COMPILE); drawLetter(_s); glEndList();
   glNewList(base+'t', GL_COMPILE); drawLetter(_t); glEndList();
   glNewList(base+'u', GL_COMPILE); drawLetter(_u); glEndList();
   glNewList(base+'v', GL_COMPILE); drawLetter(_v); glEndList();
   glNewList(base+'w', GL_COMPILE); drawLetter(_w); glEndList();
   glNewList(base+'x', GL_COMPILE); drawLetter(_x); glEndList();
   glNewList(base+'y', GL_COMPILE); drawLetter(_y); glEndList();
   glNewList(base+'z', GL_COMPILE); drawLetter(_z); glEndList();

   glNewList(base+'0', GL_COMPILE); drawLetter(_0); glEndList();
   glNewList(base+'1', GL_COMPILE); drawLetter(_1); glEndList();
   glNewList(base+'2', GL_COMPILE); drawLetter(_2); glEndList();
   glNewList(base+'3', GL_COMPILE); drawLetter(_3); glEndList();
   glNewList(base+'4', GL_COMPILE); drawLetter(_4); glEndList();
   glNewList(base+'5', GL_COMPILE); drawLetter(_5); glEndList();
   glNewList(base+'6', GL_COMPILE); drawLetter(_6); glEndList();
   glNewList(base+'7', GL_COMPILE); drawLetter(_7); glEndList();
   glNewList(base+'8', GL_COMPILE); drawLetter(_8); glEndList();
   glNewList(base+'9', GL_COMPILE); drawLetter(_9); glEndList();

   glNewList(base+'.', GL_COMPILE); drawLetter(_dot); glEndList();
   glNewList(base+':', GL_COMPILE); drawLetter(_2dot); glEndList();
   glNewList(base+'\'', GL_COMPILE); drawLetter(_aposf); glEndList();
   glNewList(base+',', GL_COMPILE); drawLetter(_coma); glEndList();
   glNewList(base+'+', GL_COMPILE); drawLetter(_plus); glEndList();
   glNewList(base+'-', GL_COMPILE); drawLetter(_minus); glEndList();
   glNewList(base+'(', GL_COMPILE); drawLetter(_lbrac); glEndList();
   glNewList(base+')', GL_COMPILE); drawLetter(_rbrac); glEndList();
   glNewList(base+'<', GL_COMPILE); drawLetter(_less); glEndList();
   glNewList(base+'>', GL_COMPILE); drawLetter(_great); glEndList();
   glNewList(base+'/', GL_COMPILE); drawLetter(_div); glEndList();
   glNewList(base+'&', GL_COMPILE); drawLetter(_and); glEndList();
   glNewList(base+'=', GL_COMPILE); drawLetter(_equal); glEndList();

   glNewList(base+' ', GL_COMPILE); glTranslatef(6.0, 0.0, 0.0); glEndList();
}


void txtOut(float x, float y, char *s, float size )
{


   glPushMatrix();

	 glTranslatef(x, y+20, 0);
	 glScalef( size*0.75, -size, 0);

	   GLsizei len = strlen(s);
	   glCallLists(len, GL_BYTE, (GLbyte *)s);
   
   glPopMatrix();

}

