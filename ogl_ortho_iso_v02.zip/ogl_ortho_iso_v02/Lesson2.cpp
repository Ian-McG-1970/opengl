/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing The Base Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <stdlib.h>
#include <stdio.h>

#define SCREEN_SCALE 2 // 2

#define HOR 256*SCREEN_SCALE
#define VER 192*SCREEN_SCALE
#define BPP 32

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool active=true;		// Window Active Flag Set To TRUE By Default

//BYTE HPOS=20, VPOS=20;

//unsigned long long testvar=0x0ffffffffffffffff;
FILE *file;
char string[256];

const void debugstring() { file=fopen("log.txt","a"); fprintf(file,string); fclose(file); }

const GLvoid ReSizeGLScene(const GLsizei width, const GLsizei height)		// Resize And Initialize The GL Window
{
	glViewport(0,0,width,height);						// Reset The Current Viewport
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	gluOrtho2D(0,width,height,0);
}

const bool InitGL()										// All Setup For OpenGL Goes Here
{
	glShadeModel(GL_FLAT);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);				// Black Background
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	// Really Nice Perspective Calculations
	glPolygonMode( GL_FRONT_AND_BACK, GL_LINE); // GL_FILL
	return true;										// Initialization Went OK
}

const void DrawBox(const float top, const float bottom, const float left, const float right, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(left, top);
		glVertex2f(right, top);
		glVertex2f(right, bottom);
		glVertex2f(left, bottom);
	glEnd();
}

const void DrawRectangle(const float p1h, const float p1v, const float p2h, const float p2v, const float p3h, const float p3v, const float p4h, const float p4v, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(p1h, p1v);
		glVertex2f(p2h, p2v);
		glVertex2f(p3h, p3v);
		glVertex2f(p4h, p4v);
	glEnd();
}

const void DrawTriangle(const float p1h, const float p1v, const float p2h, const float p2v, const float p3h, const float p3v, const float colour)
{
	glBegin(GL_TRIANGLES);
		glColor3f(colour, colour, colour);
		glVertex2f(p1h, p1v);
		glVertex2f(p2h, p2v);
		glVertex2f(p3h, p3v);
	glEnd();
}

const void PlotPoint(const float pv, const float ph, const float colour)
{
	glBegin(GL_POINTS);
		glColor3f(colour, colour, colour);
		glVertex2f(ph, pv);
	glEnd();	
}

#define LT <
#define GT >
#define LE =<
#define GE >=

#define ISOLEFT 128 // 64*SCREEN_SCALE

struct vh
{
	int v;
	int h;
};

struct tlbr_trbl_ud
{
	int tlbr;
	int trbl;
	int ud;
};

const vh VH(const int v, const int h)
{
	vh rc;
	rc.v=v;
	rc.h=h;
	return rc;
}

const tlbr_trbl_ud XYZ(const int x, const int y, const int z)
{
	tlbr_trbl_ud rc;
	rc.tlbr=x;
	rc.trbl=y;
	rc.ud=z;
	return rc;
}

tlbr_trbl_ud POS={0,0,0};


//; A = POSX
//; X = POSY
//; Y = POSZ
//;  return XY(ISOLEFT + ( (pos.x - pos.y) <<1 ), pos.x + pos.y + pos.z);
//;ISO:  STX POSY
//;      STY .POSZ +1
//;      TAY
//;
//;      SEC
//;      SBC POSY
//;;      ASL
//;      ADC #ISOWIDTH
//;      TAX
//;
//;      TYA
//;;      CLC   ; ? ALREADY CLEAR DUE TO PREVIOUS ADC?
//;      ADC POSY
//;.POSZ ADC #0
//;      TAY ; STA YPOS
//;      RTS

const vh IsometricPoint1(const tlbr_trbl_ud &pos)
{
//;	sub posy from posx
//;	result *2
//;	add left
//;	left + ((posx - posy) *2)
//;	add posz to posy
//;   add pos  to posy

	return VH(pos.tlbr + pos.trbl + pos.ud, ISOLEFT + ( (pos.tlbr - pos.trbl) <<1 ));
//	return XY(iso_top + ( (pos.x + pos.y) >>1) -pos.z, iso_left + pos.x - pos.y);
}

const vh IsometricPoint(const tlbr_trbl_ud &pos)
{
	const vh rc=IsometricPoint1(pos);
	return VH(rc.v*SCREEN_SCALE, rc.h*SCREEN_SCALE);
//	return XY(iso_top + ( (pos.x + pos.y) >>1) -pos.z, iso_left + pos.x - pos.y);
}

int frame=0;

const bool DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	ReSizeGLScene(HOR, VER); // Reset The Current Viewport

	DrawBox(5.0f, VER-5.0f, 5.0f, HOR-5.0f, 0.5f);
	DrawBox(10.0f, VER-10.0f, 10.0f, HOR-10.0f, 0.75f);
	DrawTriangle(50, 39, 150, 200, 90, 27, 0.33f);
	DrawRectangle(39, 50, 77, 51, 200, 150, 27, 90, 0.66f);
	DrawBox(40.0f, 56.0f, 40.0f, 56.0f, 0.9f);
	DrawBox(60.0f, 92.0f, 60.0f, 92.0f, 0.8f);
	DrawBox(150.0f, 158.0f, 150.0f, 158.0f, 0.7f);
	DrawBox(POS.tlbr,POS.tlbr+16.0f,POS.trbl,POS.trbl+16.0f,0.33f);
	
	PlotPoint(POS.tlbr,POS.trbl,0.99f);
	vh point = IsometricPoint(POS);
	PlotPoint(point.v,point.h,0.99f);

//	sprintf(string,"%i p hv %i %i xyz %i %i %i\n",++frame,point.v,point.h,POS.tlbr,POS.trbl,POS.ud); debugstring();

	return true;										// Keep Going
}

const GLvoid KillGLWindow()								// Properly Kill The Window
{
	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			}
			break;
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:
		{
			if (GetKeyState(VK_UP) & 0x80) { if (POS.tlbr GT 0) --POS.tlbr; }
			if (GetKeyState(VK_DOWN) & 0x80) { if (POS.tlbr LT 63) ++POS.tlbr; }
			if (GetKeyState(VK_LEFT) & 0x80) { if (POS.trbl GT 0) --POS.trbl; }
			if (GetKeyState(VK_RIGHT) & 0x80) { if (POS.trbl LT 63) ++POS.trbl; }
			if (GetKeyState(VK_SHIFT) & 0x80) { if (POS.ud GT 0) --POS.ud; }
			if (GetKeyState(VK_CONTROL) & 0x80) { if (POS.ud LT 63) ++POS.ud; }

			return 0;
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}
	return DefWindowProc(hWnd,uMsg,wParam,lParam); // Pass All Unhandled Messages To DefWindowProc
}
 
const bool CreateGLWindow(const char* title, const int width, const int height, const unsigned char bpp)
{
	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	WNDCLASS wc;
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name
	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	const DWORD dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
	const DWORD dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style

	RECT WindowRect={0,0,width,height};	// Grabs Rectangle Upper Left / Lower Right Values
	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);		// Adjust Window To True Requested Size

	if (!(hWnd=CreateWindowEx(dwExStyle, "OpenGL", title, dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance, NULL))) // Create The Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd= {sizeof(PIXELFORMATDESCRIPTOR), 1, PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA, bpp, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 00, 0, 0,PFD_MAIN_PLANE, 0,0, 0, 0}; // pfd Tells Windows How We Want Things To Be
	if (!(hDC=GetDC(hWnd)))						// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	GLuint PixelFormat;			// Holds The Results After Searching For A Match
	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}
	return true;									// Success
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	file=fopen("log.txt","w");
	if (!CreateGLWindow("NeHe's First Polygon Tutorial",HOR,VER,BPP)) // Create Our OpenGL Window
	{
		return 0;									// Quit If Window Was Not Created
	}

	MSG	msg;									// Windows Message Structure
	while (true)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				break;
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if (active && !DrawGLScene())	// Active?  Was There A Quit Received?
			{
				break;
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}
		}
	}
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}

