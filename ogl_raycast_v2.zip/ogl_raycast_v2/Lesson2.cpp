
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define HOR 640
#define VER 480
#define BPP 32

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool active=true;		// Window Active Flag Set To TRUE By Default

FILE *file;
char string[256];

const void debugstring() { file=fopen("log.txt","a"); fprintf(file,string); fclose(file); }

const GLvoid ReSizeGLScene(const GLsizei width, const GLsizei height)		// Resize And Initialize The GL Window
{
	glViewport(0,0,width,height);						// Reset The Current Viewport
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	gluOrtho2D(0,width,height,0);
}

const bool InitGL()										// All Setup For OpenGL Goes Here
{
// todo - setup top_bottom_left_right_for_each_object_type

	glShadeModel(GL_FLAT);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);				// Black Background
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	// Really Nice Perspective Calculations
	glPolygonMode( GL_FRONT_AND_BACK, GL_LINE); // GL_LINE GL_FILL
	return true;										// Initialization Went OK
}

struct vh
{
	short int v;
	short int h;
};

const void Line(const vh p0, const vh p1, const float colour)
{
	glBegin(GL_LINES);
		glColor3f(colour, colour, colour);
		glVertex2f(p0.h, p0.v);
		glVertex2f(p1.h, p1.v);
	glEnd();	
}

const vh VH(const int v, const int h)
{
	vh rc;
	rc.v=v;
	rc.h=h;
	return rc;
}

#define LT <
#define GT >
#define LE <=
#define GE >=

#define mapWidth 24
#define mapHeight 24

const unsigned char worldMap[mapWidth][mapHeight]=
{
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,2,2,2,2,2,0,0,0,0,3,0,3,0,3,0,0,0,1},
  {1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,3,0,0,0,3,0,0,0,1},
  {1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,2,2,0,2,2,0,0,0,0,3,0,3,0,3,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,4,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,0,0,0,5,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,4,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

float posX = 22, posY = 12;  //x and y start position
float dirX = -1, dirY = 0; //initial direction vector
float moveSpeed = 0.1f; //frameTime * 5.0; //the constant value is in squares/second
float rotSpeed = 0.01f; //frameTime * 3.0; //the constant value is in radians/second
float planeX = 0, planeY = 0.66; //the 2d raycaster version of camera plane

const void Input()
{
	if (GetAsyncKeyState(VK_UP) & 0x01)
	{
		const float currX = posX;
		posX += (dirX * moveSpeed);
		if (worldMap[int(posX)][int(posY)] != false) 
		{
			posX = currX;
		}
		const float currY = posY;
		posY += (dirY * moveSpeed);	
      	if (worldMap[int(posX)][int(posY)] != false) 
		{
			posY = currY;	
		}
	}

	if (GetAsyncKeyState(VK_DOWN) & 0x01)
	{
		const float currX = posX;
		posX -= (dirX * moveSpeed);
		if (worldMap[int(posX)][int(posY)] != false) 
		{
			posX = currX;
		}
		const float currY = posY;
		posY -= (dirY * moveSpeed);	
      	if (worldMap[int(posX)][int(posY)] != false) 
		{
			posY = currY;	
		}
	}

	if (GetAsyncKeyState(VK_LEFT) & 0x01) 
	{ 
		//both camera direction and camera plane must be rotated
      const float oldDirX = dirX;
      dirX = (dirX * cos(rotSpeed)) - (dirY * sin(rotSpeed));
      dirY = (oldDirX * sin(rotSpeed)) + (dirY * cos(rotSpeed));
      const float oldPlaneX = planeX;
      planeX = (planeX * cos(rotSpeed)) - (planeY * sin(rotSpeed));
      planeY = (oldPlaneX * sin(rotSpeed)) + (planeY * cos(rotSpeed));
	}

	if (GetAsyncKeyState(VK_RIGHT) & 0x01) 
	{
      //both camera direction and camera plane must be rotated
      const float oldDirX = dirX;
      dirX = (dirX * cos(-rotSpeed)) - (dirY * sin(-rotSpeed));
      dirY = (oldDirX * sin(-rotSpeed)) + (dirY * cos(-rotSpeed));
      const float oldPlaneX = planeX;
      planeX = (planeX * cos(-rotSpeed)) - (planeY * sin(-rotSpeed));
      planeY = (oldPlaneX * sin(-rotSpeed)) + (planeY * cos(-rotSpeed));
	}
}

const void DrawDDA()
{
    for (int x=0; x<HOR; ++x)
    {
    	const float cameraX = (2.0f * x) / (float)HOR - 1.0f;	// x-coordinate in camera space
    	const float rayDirX = dirX + planeX * cameraX;	// calculate ray position and direction
    	const float rayDirY = dirY + planeY * cameraX;

		// length of ray from one x or y-side to next x or y-side
    	// these are derived as:
		// deltaDistX = sqrt(1 + (rayDirY * rayDirY) / (rayDirX * rayDirX))
    	// deltaDistY = sqrt(1 + (rayDirX * rayDirX) / (rayDirY * rayDirY))
    	// which can be simplified to abs(|rayDir| / rayDirX) and abs(|rayDir| / rayDirY)
    	// where |rayDir| is the length of the vector (rayDirX, rayDirY). Its length,
    	// unlike (dirX, dirY) is not 1, however this does not matter, only the
    	// ratio between deltaDistX and deltaDistY matters, due to the way the DDA
    	// stepping further below works. So the values can be computed as below.
    	// Division through zero is prevented, even though technically that's not
    	// needed in C++ with IEEE 754 floating point values.

    	const float deltaDistX = (rayDirX == 0) ? 1e30 : abs(1.0f / rayDirX);
      	const float deltaDistY = (rayDirY == 0) ? 1e30 : abs(1.0f / rayDirY);

      	int mapX = int(posX);	// which box of the map we're in
      	int mapY = int(posY);

	    int stepX;	// what direction to step in x or y-direction (either +1 or -1)
    	float sideDistX;	// length of ray from current position to next x or y-side
      	if (rayDirX < 0)	// calculate step and initial sideDist
      	{
      		stepX = -1;
        	sideDistX = (posX - mapX) * deltaDistX;
      	}
		else
      	{
        	stepX = 1;
        	sideDistX = (mapX + 1.0f - posX) * deltaDistX;
      	}
      	int stepY;
      	float sideDistY;
      	if (rayDirY < 0)
      	{
        	stepY = -1;
        	sideDistY = (posY - mapY) * deltaDistY;
      	}
      	else
      	{
        	stepY = 1;
        	sideDistY = (mapY + 1.0f - posY) * deltaDistY;
      	}

		int side; //was a NS or a EW wall hit?
		do 	// DDA
    	{
        	if (sideDistX < sideDistY)	// jump to next map square, either in x-direction, or in y-direction
        	{
        	  sideDistX += deltaDistX;
        	  mapX += stepX;
        	  side = 0;
        	}
        	else
        	{
        	  sideDistY += deltaDistY;
        	  mapY += stepY;
        	  side = 1;
        	}
    	}
	    while (worldMap[mapX][mapY] == 0);	// DDA
      
		// Calculate distance projected on camera direction. This is the shortest distance from the point where the wall is
		// hit to the camera plane. Euclidean to center camera point would give fisheye effect!
		// This can be computed as (mapX - posX + (1 - stepX) / 2) / rayDirX for side == 0, or same formula with Y
		// for size == 1, but can be simplified to the code below thanks to how sideDist and deltaDist are computed:
		// because they were left scaled to |rayDir|. sideDist is the entire length of the ray above after the multiple
		// steps, but we subtract deltaDist once because one step more into the wall was taken above.
     	float perpWallDist;
		if (side == 0)
		{
			perpWallDist = (sideDistX - deltaDistX);
		}
		else
		{
			perpWallDist = (sideDistY - deltaDistY);
		}

		const int lineHeight = (int)(VER / perpWallDist);	//Calculate height of line to draw on screen

		int drawStart = (-lineHeight / 2) + (VER / 2);	//calculate lowest and highest pixel to fill in current stripe
		if (drawStart < 0) 
		{
			drawStart = 0;
		}
		const int drawEnd = VER -1 -drawStart;

		float color;
		switch (worldMap[mapX][mapY])	// choose wall color
		{
			case 1:  color = 0.8f;    break; //red
    	    case 2:  color = 0.16f;  break; //green
    	    case 3:  color = 0.24f;   break; //blue
    	    case 4:  color = 0.32f;  break; //white
    	    default: color = 0.40f; break; //yellow
    	}

		if (side == 1) // give x and y sides different brightness
		{
			color += color;
		}

		Line(VH(drawStart, x), VH(drawEnd, x), color); //draw the pixels of the stripe as a vertical line
  	}
}

const bool DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	ReSizeGLScene(HOR, VER); // Reset The Current Viewport

	Input();
	DrawDDA();
	
//	sprintf(string,"xyz %i %i %i\n",dir.x,dir.y,dir.z); debugstring();

	return true;										// Keep Going
}

const GLvoid KillGLWindow()								// Properly Kill The Window
{
	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			sprintf(string,"Release Of DC And RC Failed.\n"); debugstring();
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			sprintf(string,"Release Rendering Context Failed.\n"); debugstring();
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		sprintf(string,"Release Device Context Failed.\n"); debugstring();
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		sprintf(string,"Could Not Release hWnd.\n"); debugstring();
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		sprintf(string,"Could Not Unregister Class.\n"); debugstring();
		hInstance=NULL;									// Set hInstance To NULL
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=true;						// Program Is Active
			}
			else
			{
				active=false;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}
		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}
		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}
	return DefWindowProc(hWnd,uMsg,wParam,lParam); // Pass All Unhandled Messages To DefWindowProc
}
 
const bool CreateGLWindow(const char* title, const int width, const int height, const unsigned char bpp)
{
	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	WNDCLASS wc;
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name
	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		sprintf(string,"Failed To Register The Window Class.\n"); debugstring();
		return false;											// Return FALSE
	}
	
	const DWORD dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
	const DWORD dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style

	RECT WindowRect={0,0,width,height};	// Grabs Rectangle Upper Left / Lower Right Values
	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);		// Adjust Window To True Requested Size

	if (!(hWnd=CreateWindowEx(dwExStyle, "OpenGL", title, dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance, NULL))) // Create The Window
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Window Creation Error.\n"); debugstring();
		return false;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd= {sizeof(PIXELFORMATDESCRIPTOR), 1, PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA, bpp, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 00, 0, 0,PFD_MAIN_PLANE, 0,0, 0, 0}; // pfd Tells Windows How We Want Things To Be
	if (!(hDC=GetDC(hWnd)))						// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Create A GL Device Context.\n"); debugstring();
		return false;
	}

	GLuint PixelFormat;			// Holds The Results After Searching For A Match
	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Find A Suitable PixelFormat.\n"); debugstring();
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Set The PixelFormat.\n"); debugstring();
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Create A GL Rendering Context.\n"); debugstring();
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Activate The GL Rendering Context.\n"); debugstring();
		return false;
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Initialization Failed.\n"); debugstring();
		return false;								// Return FALSE
	}
	return true;									// Success
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	file=fopen("log.txt","w");
	if (!CreateGLWindow("NeHe ISO",HOR,VER,BPP)) // Create Our OpenGL Window
	{
		return 0;									// Quit If Window Was Not Created
	}

	MSG	msg;									// Windows Message Structure
	while (true)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				break;
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			if (active && !DrawGLScene())			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene() // Active?  Was There A Quit Received?
			{
				break;
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}
		}
	}
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}


