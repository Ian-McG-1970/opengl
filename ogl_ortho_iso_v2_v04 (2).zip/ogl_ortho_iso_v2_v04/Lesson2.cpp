
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <stdlib.h>
#include <stdio.h>

#define SCREEN_SCALE 1 // 2

#define HOR (256*2)*SCREEN_SCALE
#define VER (192*2)*SCREEN_SCALE
#define BPP 32

#define ISOLEFT 256 // 128 //64*SCREEN_SCALE
#define MAX_SIZE 127

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool active=true;		// Window Active Flag Set To TRUE By Default

FILE *file;
char string[256];

const void debugstring() { file=fopen("log.txt","a"); fprintf(file,string); fclose(file); }

const GLvoid ReSizeGLScene(const GLsizei width, const GLsizei height)		// Resize And Initialize The GL Window
{
	glViewport(0,0,width,height);						// Reset The Current Viewport
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	gluOrtho2D(0,width,height,0);
}

const bool InitGL()										// All Setup For OpenGL Goes Here
{
// todo - setup top_bottom_left_right_for_each_object_type

	glShadeModel(GL_FLAT);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);				// Black Background
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	// Really Nice Perspective Calculations
	glPolygonMode( GL_FRONT_AND_BACK, GL_LINE); // GL_LINE GL_FILL
	return true;										// Initialization Went OK
}

struct vh
{
	short int v;
	short int h;
};

const void DrawBox(const float top, const float bottom, const float left, const float right, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(left, top);
		glVertex2f(right, top);
		glVertex2f(right, bottom);
		glVertex2f(left, bottom);
	glEnd();
}

const void DrawRectangle(const vh p1, const vh p2, const vh p3, const vh p4, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(p1.h, p1.v);
		glVertex2f(p2.h, p2.v);
		glVertex2f(p3.h, p3.v);
		glVertex2f(p4.h, p4.v);
	glEnd();
}

const void DrawTriangle(const vh p1, const vh p2, const vh p3, const float colour)
{
	glBegin(GL_TRIANGLES);
		glColor3f(colour, colour, colour);
		glVertex2f(p1.h, p1.v);
		glVertex2f(p2.h, p2.v);
		glVertex2f(p3.h, p3.v);
	glEnd();
}

const void Plot(const vh p, const float colour)
{
	glBegin(GL_POINTS);
		glColor3f(colour, colour, colour);
		glVertex2f(p.h, p.v);
	glEnd();	
}

const void Line(const vh p0, const vh p1, const float colour)
{
	glBegin(GL_LINES);
		glColor3f(colour, colour, colour);
		glVertex2f(p0.h, p0.v);
		glVertex2f(p1.h, p1.v);
	glEnd();	
}

struct xyz
{
	short int x;
	short int y;
	short int z;
};

const xyz XYZ(const int x, const int y, const int z)
{
	xyz rc;
	rc.x=x;
	rc.y=y;
	rc.z=z;
	return rc;
}

const vh VH(const int v, const int h)
{
	vh rc;
	rc.v=v;
	rc.h=h;
	return rc;
}

struct obj
{
	short int shape;
	xyz centre;
	xyz min3d;
	xyz max3d;
	vh min2d;
	vh max2d;
	bool behind;
};

struct TLBR
{
	vh TL;
	vh BR;
	vh size2d;
};

const xyz shape_dimension_3d[]={{4,4,4},{8,8,8},{4,4,8},{8,4,4},{4,8,4},{8,4,8},{4,8,8},{8,2,8},{2,8,8},{1,1,1} };
TLBR shape_dimension_2d[256]; // todo - populate at setup with tl/br - so it doesnt need calculated in main code 

const vh IsometricPoint(const xyz &pos)
{
	return VH(pos.x + pos.y + pos.z, ISOLEFT + ( (pos.x - pos.y) <<1 ));
}

const void Setup2D(const short int shape_count)
{
	for (short int os=0; os!=shape_count; ++os)
	{
		const xyz min3d=XYZ(-shape_dimension_3d[os].x, -shape_dimension_3d[os].y, -shape_dimension_3d[os].z);
		const xyz max3d=XYZ(+shape_dimension_3d[os].x, +shape_dimension_3d[os].y, +shape_dimension_3d[os].z);

		const vh p0=IsometricPoint(XYZ(min3d.x, min3d.y, min3d.z));
		const vh p3=IsometricPoint(XYZ(min3d.x, max3d.y, max3d.z));
		const vh p4=IsometricPoint(XYZ(max3d.x, min3d.y, min3d.z));
		const vh p7=IsometricPoint(XYZ(max3d.x, max3d.y, max3d.z));

		shape_dimension_2d[os].TL=VH(p0.v, p3.h);
		shape_dimension_2d[os].BR=VH(p7.v, p4.h);
		
		shape_dimension_2d[os].size2d = VH ( (shape_dimension_2d[os].BR.v-shape_dimension_2d[os].TL.v) >>1, (shape_dimension_2d[os].BR.h-shape_dimension_2d[os].TL.h) >>1);

	sprintf(string,"setup2d %i %i mnxyz %i %i %i mxxyz %i %i %i tlbr %i %i %i %i d %i %i\n",shape_count, os, 
	min3d.x, min3d.y, min3d.z,
	max3d.x, max3d.y, max3d.z, 
	shape_dimension_2d[os].TL.v, shape_dimension_2d[os].TL.h,shape_dimension_2d[os].BR.v, shape_dimension_2d[os].BR.h, shape_dimension_2d[os].size2d.v, shape_dimension_2d[os].size2d.h); debugstring();
	}
}

obj object[256];

const float shape_colour[][3]={ {0.1,0.2,0.3},{0.5,0.3,0.1},{0.4,0.1,0.2},{0.2,0.3,0.4},{0.3,0.5,0.1},{0.1,0.3,0.5},{0.5,0.4,0.2},{0.4,0.3,0.2},{0.2,0.5,0.3}, {0.5,0.7,0.9}};

const void Draw3D(const obj &o)
{
	vh p1[8];//={
	p1[0]=IsometricPoint(XYZ(o.min3d.x,o.min3d.y,o.min3d.z));//,
//	p1[1]=IsometricPoint(XYZ(o.min3d.x,o.min3d.y,o.max3d.z));//,
	p1[2]=IsometricPoint(XYZ(o.min3d.x,o.max3d.y,o.min3d.z));//,
	p1[3]=IsometricPoint(XYZ(o.min3d.x,o.max3d.y,o.max3d.z));//,
	p1[4]=IsometricPoint(XYZ(o.max3d.x,o.min3d.y,o.min3d.z));//,
	p1[5]=IsometricPoint(XYZ(o.max3d.x,o.min3d.y,o.max3d.z));//,
	p1[6]=IsometricPoint(XYZ(o.max3d.x,o.max3d.y,o.min3d.z));//,
	p1[7]=IsometricPoint(XYZ(o.max3d.x,o.max3d.y,o.max3d.z));// };

	DrawRectangle(p1[6], p1[2], p1[0], p1[4], shape_colour[o.shape][0]);
	DrawRectangle(p1[6], p1[4], p1[5], p1[7], shape_colour[o.shape][1]);
	DrawRectangle(p1[2], p1[3], p1[7], p1[6], shape_colour[o.shape][2]);
}

#define LT <
#define GT >
#define LE <=
#define GE >=

int objects=0;

const short int mini(const short int a, const short int b)
{
	return (a LE b) ? a : b;
}

const short int maxi(const short int a, const short int b)
{
	return (a GE b) ? a : b;
}

short int object_pos[256];

const float Colour[]={0.55f,0.60f,0.65f,0.70f,0.75f,0.80f,0.85f,0.90f,0.95f,0.53f,0.58f,0.63f,0.68f,0.73f,0.78f,0.83f,0.88f,0.93f,0.98f};

const void Draw2D(const short int pos, const float colour)
{
	DrawBox(object[pos].min3d.x,object[pos].max3d.x,object[pos].min3d.y,object[pos].max3d.y,colour);
}

const void AddObject(const short int shape)
{
	object[objects].centre=XYZ(0,0,0);
	object[objects].shape=shape;
	++objects;
}

const bool Collision(const obj &o1, const obj &o2)
{
	if (o1.min3d.x < (o2.max3d.x) && (o1.max3d.x) > o2.min3d.x 
	 && o1.min3d.y < (o2.max3d.y) && (o1.max3d.y) > o2.min3d.y
 	 && o1.min3d.z < (o2.max3d.z) && (o1.max3d.z) > o2.min3d.z)
	{
		return true;
	}
	return false;
}

const bool Movement(const xyz &centre, const short int pos)
{
	obj item2;
	item2.centre=XYZ(object[pos].centre.x+centre.x, object[pos].centre.y+centre.y, object[pos].centre.z+centre.z);
	item2.min3d=XYZ(item2.centre.x-shape_dimension_3d[object[pos].shape].x, item2.centre.y-shape_dimension_3d[object[pos].shape].y, item2.centre.z-shape_dimension_3d[object[pos].shape].z);
	item2.max3d=XYZ(item2.centre.x+shape_dimension_3d[object[pos].shape].x, item2.centre.y+shape_dimension_3d[object[pos].shape].y, item2.centre.z+shape_dimension_3d[object[pos].shape].z);

	for (short int o=0; o!=objects; ++o)
	{
		if (o==pos) continue;
		if (Collision(item2, object[o])==true)
		{
			return false;
		}
	}
	
	memcpy(&object[pos].min3d, &item2.min3d, sizeof(object[pos].min3d));
	memcpy(&object[pos].max3d, &item2.max3d, sizeof(object[pos].max3d));
	memcpy(&object[pos].centre, &item2.centre, sizeof(object[pos].centre));

	const vh p0=IsometricPoint(XYZ(object[pos].min3d.x, object[pos].min3d.y, object[pos].min3d.z));
	const vh p3=IsometricPoint(XYZ(object[pos].min3d.x, object[pos].max3d.y, object[pos].max3d.z));
	const vh p4=IsometricPoint(XYZ(object[pos].max3d.x, object[pos].min3d.y, object[pos].min3d.z));
	const vh p7=IsometricPoint(XYZ(object[pos].max3d.x, object[pos].max3d.y, object[pos].max3d.z));

	object[pos].min2d.v=p0.v;
	object[pos].min2d.h=p3.h;
	object[pos].max2d.v=p7.v;
	object[pos].max2d.h=p4.h;

	return true;
}

const void Setup()
{
	Setup2D( sizeof(shape_dimension_3d) / sizeof(shape_dimension_3d[0]) );

	srand(GetTickCount());

	objects=0;
	for (short int i=0; i!=33;)
	{
		AddObject(rand()%10);
		do
		{
		}
		while (Movement(XYZ(rand()&127, rand()&127, 0-shape_dimension_3d[object[objects-1].shape].z), objects-1)!=true);
		++i;
	}
}

const xyz Input()
{
	xyz dir=XYZ(0,0,0);
		
	if (GetAsyncKeyState(VK_UP) & 0x01)
	{
		--dir.x;
	}

	if (GetAsyncKeyState(VK_DOWN) & 0x01)
	{
		++dir.x;
	}

	if (GetAsyncKeyState(VK_LEFT) & 0x01) 
	{ 
		--dir.y;
	}

	if (GetAsyncKeyState(VK_RIGHT) & 0x01) 
	{
		++dir.y;
	}
	
	if (GetAsyncKeyState(VK_PRIOR) & 0x01)
	{
		--dir.z;
	}

	if (GetAsyncKeyState(VK_NEXT) & 0x01) 
	{ 
		++dir.z;
	}

	if (GetAsyncKeyState(VK_SPACE) & 0x01)
	{
		Setup();
	}
	return dir;
}

const bool Overlap(const obj &first, const obj &second) // overlap if h and v both overlap.
{
	if ( (first.min2d.h GT second.max2d.h)
	  || (first.max2d.h LT second.min2d.h)
	  || (first.min2d.v GT second.max2d.v) 
	  || (first.max2d.v LT second.min2d.v) ) return false;
    return true;
}

const bool IsBehind(const obj &first, const obj &second) 
{
    if ( (second.min3d.x GE first.max3d.x) 					// test for intersection x-axis (lower x value is in front)
      || (second.min3d.y GE first.max3d.y) 					// test for intersection y-axis (lower y value is in front)
      || (first.min3d.z GE second.max3d.z) ) return false; 	// test for intersection z-axis (higher z value is in front)
	return true;
}

const void SortObjectList(const int objects)
{
	for (short int o=0; o!=objects; ++o)
	{
		object_pos[o]=o;
	}

	for (short int objects_left=objects, drawn=0; objects_left!=0; )
	{

		for (short int o=0; o!=objects_left; ++o)
		{
			object[object_pos[o]].behind=true;
		}

		for (short int f=0; f!=objects_left-1; ++f)
		{
			for (short int b=f+1; b!=objects_left; ++b)
			{
				if (Overlap(object[object_pos[f]], object[object_pos[b]])==true)
				{
					if (IsBehind(object[object_pos[f]], object[object_pos[b]])==true)
					{
						object[object_pos[f]].behind=false;
					}
					else
					{
						object[object_pos[b]].behind=false;
					}
				}
			}
		}

		for (short int o=0; o!=objects_left; ++o)
		{
			if (object[object_pos[o]].behind==true)
			{
				Draw3D((object[object_pos[o]]));
				Draw2D(object_pos[o],5);

				++drawn;
				--objects_left;
				object_pos[o]=object_pos[objects_left];
				--o;
			}
		}
	}
}

const bool DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	ReSizeGLScene(HOR, VER); // Reset The Current Viewport

	const xyz dir=Input();
	Movement(dir,objects-1);
	SortObjectList(objects);

//	sprintf(string,"xyz %i %i %i\n",dir.x,dir.y,dir.z); debugstring();

	return true;										// Keep Going
}

const GLvoid KillGLWindow()								// Properly Kill The Window
{
	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			sprintf(string,"Release Of DC And RC Failed.\n"); debugstring();
//			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			sprintf(string,"Release Rendering Context Failed.\n"); debugstring();
//			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		sprintf(string,"Release Device Context Failed.\n"); debugstring();
//		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		sprintf(string,"Could Not Release hWnd.\n"); debugstring();
//		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		sprintf(string,"Could Not Unregister Class.\n"); debugstring();
//		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=true;						// Program Is Active
			}
			else
			{
				active=false;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}
		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}
		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}
	return DefWindowProc(hWnd,uMsg,wParam,lParam); // Pass All Unhandled Messages To DefWindowProc
}
 
const bool CreateGLWindow(const char* title, const int width, const int height, const unsigned char bpp)
{
	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	WNDCLASS wc;
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name
	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		sprintf(string,"Failed To Register The Window Class.\n"); debugstring();
//		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	const DWORD dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
	const DWORD dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style

	RECT WindowRect={0,0,width,height};	// Grabs Rectangle Upper Left / Lower Right Values
	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);		// Adjust Window To True Requested Size

	if (!(hWnd=CreateWindowEx(dwExStyle, "OpenGL", title, dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance, NULL))) // Create The Window
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Window Creation Error.\n"); debugstring();
//		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd= {sizeof(PIXELFORMATDESCRIPTOR), 1, PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA, bpp, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 00, 0, 0,PFD_MAIN_PLANE, 0,0, 0, 0}; // pfd Tells Windows How We Want Things To Be
	if (!(hDC=GetDC(hWnd)))						// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Create A GL Device Context.\n"); debugstring();
//		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	GLuint PixelFormat;			// Holds The Results After Searching For A Match
	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Find A Suitable PixelFormat.\n"); debugstring();
//		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Set The PixelFormat.\n"); debugstring();
//		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Create A GL Rendering Context.\n"); debugstring();
//		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Can't Activate The GL Rendering Context.\n"); debugstring();
//		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		sprintf(string,"Initialization Failed.\n"); debugstring();
//		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}
	return true;									// Success
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	file=fopen("log.txt","w");
	if (!CreateGLWindow("NeHe ISO",HOR,VER,BPP)) // Create Our OpenGL Window
	{
		return 0;									// Quit If Window Was Not Created
	}
	Setup();

	MSG	msg;									// Windows Message Structure
	while (true)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				break;
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			if (active && !DrawGLScene())			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene() // Active?  Was There A Quit Received?
			{
				break;
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}
		}
	}
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}

