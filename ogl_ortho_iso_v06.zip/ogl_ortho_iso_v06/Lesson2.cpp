
#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include <stdlib.h>
#include <stdio.h>

#define SCREEN_SCALE 1 // 2

#define HOR (256*2)*SCREEN_SCALE
#define VER (192*2)*SCREEN_SCALE
#define BPP 32

#define ISOLEFT 256 // 128 //64*SCREEN_SCALE
#define MAX_SIZE 127

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool active=true;		// Window Active Flag Set To TRUE By Default

FILE *file;
char string[256];

const void debugstring() { file=fopen("log.txt","a"); fprintf(file,string); fclose(file); }

const GLvoid ReSizeGLScene(const GLsizei width, const GLsizei height)		// Resize And Initialize The GL Window
{
	glViewport(0,0,width,height);						// Reset The Current Viewport
	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix
	gluOrtho2D(0,width,height,0);
}

const bool InitGL()										// All Setup For OpenGL Goes Here
{
	glShadeModel(GL_FLAT);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);				// Black Background
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);	// Really Nice Perspective Calculations
	glPolygonMode( GL_FRONT_AND_BACK, GL_FILL); // GL_LINE GL_FILL
	return true;										// Initialization Went OK
}

const void DrawBox(const float top, const float bottom, const float left, const float right, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(left, top);
		glVertex2f(right, top);
		glVertex2f(right, bottom);
		glVertex2f(left, bottom);
	glEnd();
}

const void DrawRectangle(const float p1h, const float p1v, const float p2h, const float p2v, const float p3h, const float p3v, const float p4h, const float p4v, const float colour)
{
	glBegin(GL_QUADS);
		glColor3f(colour, colour, colour);
		glVertex2f(p1h, p1v);
		glVertex2f(p2h, p2v);
		glVertex2f(p3h, p3v);
		glVertex2f(p4h, p4v);
	glEnd();
}

const void DrawTriangle(const float p1h, const float p1v, const float p2h, const float p2v, const float p3h, const float p3v, const float colour)
{
	glBegin(GL_TRIANGLES);
		glColor3f(colour, colour, colour);
		glVertex2f(p1h, p1v);
		glVertex2f(p2h, p2v);
		glVertex2f(p3h, p3v);
	glEnd();
}

const void Plot(const float pv, const float ph, const float colour)
{
	glBegin(GL_POINTS);
		glColor3f(colour, colour, colour);
		glVertex2f(ph, pv);
	glEnd();	
}

const void Line(const float p0v, const float p0h, const float p1v, const float p1h, const float colour)
{
	glBegin(GL_LINES);
		glColor3f(colour, colour, colour);
		glVertex2f(p0h, p0v);
		glVertex2f(p1h, p1v);
	glEnd();	
}

struct xyz
{
	int x;
	int y;
	int z;
};

const xyz XYZ(const int x, const int y, const int z)
{
	xyz rc;
	rc.x=x;
	rc.y=y;
	rc.z=z;
	return rc;
}

struct vh
{
	int v;
	int h;
};

const vh VH(const int v, const int h)
{
	vh rc;
	rc.v=v;
	rc.h=h;
	return rc;
}

struct obj
{
	xyz centre;
	xyz min;
	xyz max;
	vh overlap_x;
	vh overlap_y;
	vh overlap_h;
	int shape;
	vh pos;
	bool behind;
};

const vh IsometricPoint1(const xyz &pos)
{
	return VH(pos.x + pos.y + pos.z, ISOLEFT + ( (pos.x - pos.y) <<1 ));
}

const vh IsometricPoint(const xyz &pos)
{
	const vh rc=IsometricPoint1(pos);
	return VH(rc.v*SCREEN_SCALE, rc.h*SCREEN_SCALE);
//	return XY(iso_top + ( (pos.x + pos.y) >>1) -pos.z, iso_left + pos.x - pos.y);
}

obj object[256];

const float shape_colour[][3]={ {0.1,0.2,0.3},{0.5,0.3,0.1},{0.4,0.1,0.2},{0.2,0.3,0.4},{0.3,0.5,0.1},{0.1,0.3,0.5},{0.5,0.4,0.2},{0.4,0.3,0.2},{0.2,0.5,0.3}, };

const void Draw3D(const obj &o)
{
	const float col1=shape_colour[o.shape][0];
	const float col2=shape_colour[o.shape][1];
	const float col3=shape_colour[o.shape][2];
		
	const vh p0=IsometricPoint(XYZ(o.min.x,o.min.y,o.min.z));
//	const vh p1=IsometricPoint(XYZ(o.min.x,o.min.y,o.max.z));
	const vh p2=IsometricPoint(XYZ(o.min.x,o.max.y,o.min.z));
	const vh p3=IsometricPoint(XYZ(o.min.x,o.max.y,o.max.z));
	const vh p4=IsometricPoint(XYZ(o.max.x,o.min.y,o.min.z));
	const vh p5=IsometricPoint(XYZ(o.max.x,o.min.y,o.max.z));
	const vh p6=IsometricPoint(XYZ(o.max.x,o.max.y,o.min.z));
	const vh p7=IsometricPoint(XYZ(o.max.x,o.max.y,o.max.z));

	DrawRectangle(p6.h,p6.v,p2.h,p2.v,p0.h,p0.v,p4.h,p4.v,col1);
	DrawRectangle(p6.h,p6.v,p4.h,p4.v,p5.h,p5.v,p7.h,p7.v,col2);
	DrawRectangle(p2.h,p2.v,p3.h,p3.v,p7.h,p7.v,p6.h,p6.v,col3);
}

#define LT <
#define GT >
#define LE =<
#define GE >=

const void Plot(const vh point, const float colour)
{
	Plot(point.v, point.h, colour);
}

xyz POS=XYZ(0,0,0);

int objects=0;

int frame=0;

const xyz shape_dimension[]={{4,4,4},{8,8,8},{4,4,8},{8,4,4},{4,8,4},{8,4,8},{4,8,8},{8,2,8},{2,8,8} };
const vh shape_offset[]={    {8,8},  {16,16},{12,8}, {10,12},{10,12},{14,12},{14,12}, {13,10},{13,10} };

const void AddObject(const int shape)
{
	object[objects].centre=XYZ(0,0,0);
	object[objects].shape=shape;
	++objects;
}

const int mini(const int a, const int b)
{
	if (a LT b) return a;
	return b;
}

const int maxi(const int a, const int b)
{
	if (a GT b) return a;
	return b;
}

const bool Collision(const obj &o1, const obj &o2)
{
	if (o1.min.x < (o2.max.x) && (o1.max.x) > o2.min.x 
		&& o1.min.y < (o2.max.y) && (o1.max.y) > o2.min.y
		&& o1.min.z < (o2.max.z) && (o1.max.z) > o2.min.z)
	{
		return true;
	}
	return false;
}

const bool Movement(const xyz &centre, const int pos)
{
	obj item2;
	item2.centre=XYZ(object[pos].centre.x+centre.x, object[pos].centre.y+centre.y, object[pos].centre.z+centre.z);
	item2.min=XYZ(item2.centre.x-shape_dimension[object[pos].shape].x, item2.centre.y-shape_dimension[object[pos].shape].y, item2.centre.z-shape_dimension[object[pos].shape].z);
	item2.max=XYZ(item2.centre.x+shape_dimension[object[pos].shape].x, item2.centre.y+shape_dimension[object[pos].shape].y, item2.centre.z+shape_dimension[object[pos].shape].z);

	for (int o=0; o!=objects; ++o)
	{
		if (o==pos) continue;
		if (Collision(item2, object[o])==true)
		{
			return false;
		}
	}
	memcpy(&object[pos].min,&item2.min,sizeof(object[pos].min));
	memcpy(&object[pos].max,&item2.max,sizeof(object[pos].max));
	object[pos].centre=item2.centre;
	const vh loc=IsometricPoint(centre);
	object[pos].pos=VH(loc.v-shape_offset[object[pos].shape].v,loc.h-shape_offset[object[pos].shape].h);
	object[pos].overlap_x=VH(object[pos].min.x-object[pos].max.z,object[pos].max.x-object[pos].min.z);
	object[pos].overlap_y=VH(object[pos].min.y-object[pos].max.z,object[pos].max.y-object[pos].min.z);
	const vh fs=IsometricPoint(XYZ(object[pos].min.x,object[pos].max.y,object[pos].min.z));
	const vh fe=IsometricPoint(XYZ(object[pos].max.x,object[pos].min.y,object[pos].min.z));
	object[pos].overlap_h=VH(fs.h,fe.h);

	return true;
}

int object_pos[256];

const bool IsBehind2(const vh &first, const vh &second)
{
	if ( (first.h LT second.v) || (second.h LT first.v) ) return false;
	return true;
}

const bool IsBehind(const obj &o1, const obj &o2)
{
	if ( (o1.min.z GE o2.max.z) || (o1.min.x GE o2.max.x) || (o1.min.y GE o2.max.y) ) return true;
	return false;
}

const bool Overlap(const obj &first, const obj &second)
{
	if ( (IsBehind2(first.overlap_x,second.overlap_x)==true) && (IsBehind2(first.overlap_y,second.overlap_y)==true) && (IsBehind2(first.overlap_h,second.overlap_h)==true) )
	{
		return true;
	}
	return false;
}

const float Colour[]={0.05f,0.10f,0.15f,0.20f,0.25f,0.30f,0.35f,0.40f,0.45f,0.50f,0.55f,0.60f,0.65f,0.70f,0.75f,0.80f,0.85f,0.90f,0.95f};

const void Draw2D(const int pos, const float colour)
{
	DrawBox(object[pos].min.x,object[pos].max.x,object[pos].min.y,object[pos].max.y,colour);
}

const void SortObjectList(const int objects)
{
	for (int o=0; o!=objects; ++o)
	{
		object_pos[o]=o;
	}

	for (int objects_left=objects, drawn=0; objects_left!=0; )
	{

		for (int o=0; o!=objects_left; ++o)
		{
			object[object_pos[o]].behind=true;
		}

		for (int f=0; f!=objects_left-1; ++f)
		{
			for (int b=f+1; b!=objects_left; ++b)
			{
				if (Overlap(object[object_pos[f]],object[object_pos[b]])==true)
				{
					if (IsBehind(object[object_pos[f]],object[object_pos[b]])==true)
					{
						object[object_pos[f]].behind=false;
					}
					else
					{
						object[object_pos[b]].behind=false;
					}
				}
			}
		}

		for (int o=0; o!=objects_left; ++o)
		{
			if (object[object_pos[o]].behind==true)
			{
				Draw2D(object_pos[o],0.25);
				Draw3D((object[object_pos[o]]));

				++drawn;
				--objects_left;
				object_pos[o]=object_pos[objects_left];
				--o;
			}
		}
	}
}

const void Setup()
{
	srand(GetTickCount());

//	xyz t1[8];
//	t1[0]=XYZ(MAX_SIZE, MAX_SIZE, MAX_SIZE);
//	t1[1]=XYZ(MAX_SIZE, MAX_SIZE, 0);
//	t1[2]=XYZ(MAX_SIZE, 0, MAX_SIZE);
//	t1[3]=XYZ(MAX_SIZE, 0, 0);
//	t1[4]=XYZ(0, MAX_SIZE, MAX_SIZE);
//	t1[5]=XYZ(0, MAX_SIZE, 0);
//	t1[6]=XYZ(0, 0, MAX_SIZE);
//	t1[7]=XYZ(0, 0, 0);
//	for (int i=0; i!=8; ++i)
//	{
//		const vh t=IsometricPoint(t1[i]);
//		fprintf(file,"i %i xyz %i %i %i pxy %i %i\n",i,t1[i].x,t1[i].y,t1[i].z,t.v,t.h);
//	}

	for (int o=0; o!=8; ++o)
	{
//		fprintf(file,"o %ld\n",o);
		xyz p1[8];
		p1[0]=XYZ(shape_dimension[o].x,shape_dimension[o].y,shape_dimension[o].z);
		p1[1]=XYZ(shape_dimension[o].x,shape_dimension[o].y,-shape_dimension[o].z);
		p1[2]=XYZ(shape_dimension[o].x,-shape_dimension[o].y,shape_dimension[o].z);
		p1[3]=XYZ(shape_dimension[o].x,-shape_dimension[o].y,-shape_dimension[o].z);
		p1[4]=XYZ(-shape_dimension[o].x,shape_dimension[o].y,shape_dimension[o].z);
		p1[5]=XYZ(-shape_dimension[o].x,shape_dimension[o].y,-shape_dimension[o].z);
		p1[6]=XYZ(-shape_dimension[o].x,-shape_dimension[o].y,shape_dimension[o].z);
		p1[7]=XYZ(-shape_dimension[o].x,-shape_dimension[o].y,-shape_dimension[o].z);
		vh p2[8];
		p2[0]=IsometricPoint(p1[0]);
		p2[1]=IsometricPoint(p1[1]);
		p2[2]=IsometricPoint(p1[2]);
		p2[3]=IsometricPoint(p1[3]);
		p2[4]=IsometricPoint(p1[4]);
		p2[5]=IsometricPoint(p1[5]);
		p2[6]=IsometricPoint(p1[6]);
		p2[7]=IsometricPoint(p1[7]);
		int minx=p2[0].v;
		int maxx=p2[0].v;
		int miny=p2[0].h;
		int maxy=p2[0].h;
		for (int p=0; p!=8; ++p)
		{
			minx=mini(minx,p2[p].v);
			maxx=maxi(maxx,p2[p].v);
			miny=mini(miny,p2[p].h);
			maxy=maxi(maxy,p2[p].h);
//			fprintf(file,"p %ld p1x %ld p1y %ld p1z %ld p2x %ld p2y %ld\n",p,p1[p].x,p1[p].y,p1[p].z,p2[p].x,p2[p].y);

		}
//		fprintf(file,"minx %ld miny %ld maxx %ld maxy %ld xdiff %ld ydiff %ld\n",minx,maxx,miny,maxy,maxx-minx,maxy-miny);
	}

	objects=0;

	for (int i=0; i!=33;)
	{
		AddObject(rand()%9);
		do
		{
		}
//		while (Movement(XYZ(rand()&127, rand()&127, rand()&127+shape_dimension[object[objects-1].shape].z), objects-1)!=true);
		while (Movement(XYZ(rand()&MAX_SIZE, rand()&MAX_SIZE, 0+shape_dimension[object[objects-1].shape].z), objects-1)!=true);
		++i;
	}
}

struct keypress
{
	bool Up;
	bool Down;
	bool Left;
	bool Right;
	bool Front;
	bool Back;
};

keypress Key;

const void Input()
{
//	sprintf(string,"%i p hv %i %i xyz %i %i %i\n",++frame,point.v,point.h,POS.tlbr,POS.trbl,POS.ud); debugstring();
	
	POS=XYZ(0,0,0);
	
	if (GetKeyState(VK_UP) & 0x80)
	{
		if (Key.Front==false)
		{
			Key.Front=true;
			--POS.x;
		}
	}
	else
	{
		Key.Front=false;
	}

	if (GetKeyState(VK_DOWN) & 0x80)
	{
		if (Key.Back==false)
		{
			Key.Back=true;
			++POS.x;
		}
	}
	else
	{
		Key.Back=false;
	}

	if (GetKeyState(VK_LEFT) & 0x80) 
	{ 
		if (Key.Left==false)
		{
			Key.Left=true;
			--POS.y;
		}
	}
	else
	{
		Key.Left=false;
	}

	if (GetKeyState(VK_RIGHT) & 0x80) 
	{
		if (Key.Right==false)
		{
			Key.Right=true;
			++POS.y;
		}
	}
	else
	{
		Key.Right=false;
	}
	
	if (GetKeyState(VK_PRIOR) & 0x80)
	{
		if (Key.Up==false)
		{
			Key.Up=true;
			--POS.z;
		}
	}
	else
	{
		Key.Up=false;
	}

	if (GetKeyState(VK_NEXT) & 0x80) 
	{ 
		if (Key.Down==false)
		{
			Key.Down=true;
			++POS.z;
		}
	}
	else
	{
		Key.Down=false;
	}

	if (GetKeyState(VK_SPACE) & 0x80)
	{
		Setup();
	}
}
		
const bool DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT);
	ReSizeGLScene(HOR, VER); // Reset The Current Viewport

	Input();
	Movement(POS,objects-1);
	SortObjectList(objects);

	sprintf(string,"%i p xyz %i %i %i\n",++frame,POS.x,POS.y,POS.z); debugstring();

	return true;										// Keep Going
}

const GLvoid KillGLWindow()								// Properly Kill The Window
{
	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

//		case WM_SYSCOMMAND:
//		{
//			switch (wParam)
//			{
//				case SC_SCREENSAVE:
//				case SC_MONITORPOWER:
//					return 0;
//			}
//			break;
//		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

//		case WM_KEYDOWN:
//		{
//			Input();
//			return 0;
//		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}
	return DefWindowProc(hWnd,uMsg,wParam,lParam); // Pass All Unhandled Messages To DefWindowProc
}
 
const bool CreateGLWindow(const char* title, const int width, const int height, const unsigned char bpp)
{
	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	WNDCLASS wc;
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name
	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;											// Return FALSE
	}
	
	const DWORD dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
	const DWORD dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style

	RECT WindowRect={0,0,width,height};	// Grabs Rectangle Upper Left / Lower Right Values
	AdjustWindowRectEx(&WindowRect, dwStyle, false, dwExStyle);		// Adjust Window To True Requested Size

	if (!(hWnd=CreateWindowEx(dwExStyle, "OpenGL", title, dwStyle | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance, NULL))) // Create The Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd= {sizeof(PIXELFORMATDESCRIPTOR), 1, PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER, PFD_TYPE_RGBA, bpp, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 00, 0, 0,PFD_MAIN_PLANE, 0,0, 0, 0}; // pfd Tells Windows How We Want Things To Be
	if (!(hDC=GetDC(hWnd)))						// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	GLuint PixelFormat;			// Holds The Results After Searching For A Match
	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return false;								// Return FALSE
	}
	return true;									// Success
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	file=fopen("log.txt","w");
	if (!CreateGLWindow("NeHe's First Polygon Tutorial",HOR,VER,BPP)) // Create Our OpenGL Window
	{
		return 0;									// Quit If Window Was Not Created
	}
	Setup();

	MSG	msg;									// Windows Message Structure
	while (true)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				break;
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if (active && !DrawGLScene())	// Active?  Was There A Quit Received?
			{
				break;
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}
		}
	}
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}

